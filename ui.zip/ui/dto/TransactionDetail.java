package edu.mum.cs.cs525.labs.exercises.project.ui.dto;

public class TransactionDetail {
}
