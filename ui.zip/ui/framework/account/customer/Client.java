package edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.customer;


public class Client {
    private String name;
    private Address address;


    private String email;
}
