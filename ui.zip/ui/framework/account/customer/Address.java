package edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.customer;

public class Address {
    private String street;
    private String city;
    private String state;
    private Integer zipcode;
}
