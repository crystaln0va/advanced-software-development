package edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.customer;

public class Company extends Client{
    private Integer noEmployees;
}
