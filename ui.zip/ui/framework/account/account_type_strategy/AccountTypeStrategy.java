package edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.account_type_strategy;

import java.io.Serializable;

public interface  AccountTypeStrategy extends Serializable {
}
