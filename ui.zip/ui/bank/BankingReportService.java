package edu.mum.cs.cs525.labs.exercises.project.ui.bank;

import edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.Account;
import edu.mum.cs.cs525.labs.exercises.project.ui.framework.account.ReportingService;

import java.util.List;

public class BankingReportService implements ReportingService {
    
    @Override
    public String getReport(List<Account> allAccounts) {
        return null;
    }
}
